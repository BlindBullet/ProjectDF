﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using UnityEngine;
using Utils;

public abstract class UILerpAnimationBase : MonoBehaviour
{
	public enum AnimationType
	{
		ToTarget,
		ToOrigin
	}

	public abstract class Templete<T> : UILerpAnimationBase
	{
		private ICoroutineBinder _sequence;

		protected abstract void OnBegin(T from, bool isPlayForward);

		protected abstract void OnTransition(T from, T to, float alpha);

		protected abstract void OnEnd(T to, bool isPlayForward);

		protected abstract T GetFrom();

		protected abstract T GetTo();

		protected abstract bool TryExecuteReverseSequence();

		protected sealed override void OnPlay(bool isPlayForward, bool skipAnimation)
		{
			if (skipAnimation || !gameObject.activeInHierarchy)
			{
				if (!_isInitalized)
				{
					Awake();
				}

				if (AniType == AnimationType.ToTarget)
				{
					OnEnd(isPlayForward ? GetTo() : GetFrom(), isPlayForward);
				}
				else if (AniType == AnimationType.ToOrigin)
				{
					OnEnd(isPlayForward ? GetFrom() : GetTo(), isPlayForward);
				}
			}
			else
			{
				this.StartUniqueCoroutine(ref this._sequence, FillSequence(isPlayForward));
			}
		}

		private IEnumerator FillSequence(bool isPlayForward)
		{
			T from = isPlayForward ? GetFrom() : GetTo();
			T to = isPlayForward ? GetTo() : GetFrom();

			OnBegin(from, isPlayForward);

			for (float time = 0; time < AniTime; time += Time.deltaTime)
			{
				OnTransition(from, to, Curve.Evaluate(time / AniTime));
				yield return null;
			}

			if (TryExecuteReverseSequence())
			{
				for (float time = 0; time < AniTime; time += Time.deltaTime)
				{
					OnTransition(to, from, Curve.Evaluate(time / AniTime));
					yield return null;
				}
			}

			if (AniType == AnimationType.ToTarget)
			{
				OnEnd(to, isPlayForward);
			}
			else if (AniType == AnimationType.ToOrigin)
			{
				OnEnd(from, isPlayForward);
			}
		}
	}

	public AnimationType AniType;

	[SerializeField]
	protected float AniTime = 0.7f;

	[SerializeField]
	protected AnimationCurve Curve;

	private bool _isInitalized;

	protected virtual void Awake()
	{
		_isInitalized = true;
		if (Curve.keys.Length == 0)
		{
			Curve.AddKey(new Keyframe(0f, 0f, 4.85f, 4.85f));
			Curve.AddKey(new Keyframe(0.15f, 0.729f, 1.489f, 1.160f));
			Curve.AddKey(new Keyframe(1f, 1f, 0f, 0f));
		}
	}

	protected virtual void Start()
	{
	}

	public virtual void Play(bool playForward, bool skipAnimation)
	{
		OnPlay(playForward, skipAnimation);
	}

	protected abstract void OnPlay(bool playForward, bool skipAnimation);
}